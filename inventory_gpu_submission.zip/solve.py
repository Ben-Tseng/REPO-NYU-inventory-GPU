import itertools
import json
import math
import time

import numpy as np

from model import capPmf, evtPmf, fifoNext


def getXp(name):
    if name == "cpu":
        return np
    if name != "cuda":
        raise ValueError("backend must be 'cpu' or 'cuda'")
    try:
        import cupy as cp
    except ImportError as exc:
        raise RuntimeError(
            "CUDA backend needs CuPy. Install the wheel matching your CUDA version."
        ) from exc
    if cp.cuda.runtime.getDeviceCount() < 1:
        raise RuntimeError("CuPy is installed, but no CUDA device is available")
    return cp


def oneVI(life=2, maxOrd=9, mean=5.0, price=1.0, cost=0.5,
          tol=1e-4, maxIt=1000):
    base = maxOrd + 1
    states = list(itertools.product(range(base), repeat=life))
    pos = {state: idx for idx, state in enumerate(states)}
    vals = np.zeros(len(states), dtype=np.float64)
    policy = np.zeros(len(states), dtype=np.int32)
    low = high = math.nan

    for it in range(1, maxIt + 1):
        old = vals.copy()
        for idx, state in enumerate(states):
            stock = sum(state)
            probs = capPmf(mean, stock)
            sale = np.arange(stock + 1, dtype=np.float64)
            reward = price * float(probs @ sale)
            scores = np.empty(base, dtype=np.float64)
            for order in range(base):
                fut = 0.0
                for sold, prob in enumerate(probs):
                    nxt = fifoNext(state, order, sold)
                    fut += prob * old[pos[nxt]]
                scores[order] = reward + fut - cost * order
            policy[idx] = int(scores.argmax())
            vals[idx] = scores[policy[idx]]

        diff = vals - old
        low = float(diff.min())
        high = float(diff.max())
        vals -= vals[0]
        if high - low < tol:
            break

    return {
        "iters": it,
        "span": high - low,
        "profit": (low + high) / 2.0,
        "low": low,
        "high": high,
        "max_order": int(policy.max()),
        "policy": policy,
        "value": vals,
    }


def makeGrid(levelA, levelB):
    shape = (levelA, levelA, levelB, levelB)
    grid = np.indices(shape, dtype=np.int32)
    return np.stack([part.reshape(-1) for part in grid], axis=1)


def twoVI(levelA, levelB, meanA, meanB, gamma=0.5, priceA=1.0,
          priceB=1.0, costA=0.5, costB=0.5, tol=1e-4,
          maxIt=1000, fixed=0, batch=64, backend="cpu", verbose=False):
    xp = getXp(backend)
    host = makeGrid(levelA, levelB)
    states = xp.asarray(host)
    count = len(host)
    maxA = 2 * (levelA - 1)
    maxB = 2 * (levelB - 1)
    probs = evtPmf(meanA, meanB, maxA, maxB, gamma)
    probs = xp.asarray(probs.reshape(maxA + 1, maxB + 1, -1))

    soldA, soldB = np.meshgrid(
        np.arange(maxA + 1, dtype=np.int32),
        np.arange(maxB + 1, dtype=np.int32),
        indexing="ij",
    )
    soldA = xp.asarray(soldA.reshape(-1))
    soldB = xp.asarray(soldB.reshape(-1))
    qa, qb = np.meshgrid(
        np.arange(levelA, dtype=np.int32),
        np.arange(levelB, dtype=np.int32),
        indexing="ij",
    )
    qa = xp.asarray(qa.reshape(-1))
    qb = xp.asarray(qb.reshape(-1))
    actOff = qa * (levelB * levelB) + qb
    actCost = costA * qa + costB * qb

    vals = xp.zeros(count, dtype=xp.float64)
    policy = xp.zeros(count, dtype=xp.int32)
    low = high = math.nan
    start = time.perf_counter()
    limit = fixed if fixed else maxIt

    for it in range(1, limit + 1):
        old = vals.copy()
        for begin in range(0, count, batch):
            end = min(begin + batch, count)
            cur = states[begin:end]
            oldA = cur[:, 0]
            newA = cur[:, 1]
            oldB = cur[:, 2]
            newB = cur[:, 3]
            stockA = oldA + newA
            stockB = oldB + newB
            prob = probs[stockA, stockB]

            useA = xp.maximum(soldA[None, :] - oldA[:, None], 0)
            useB = xp.maximum(soldB[None, :] - oldB[:, None], 0)
            nextA = xp.maximum(newA[:, None] - useA, 0)
            nextB = xp.maximum(newB[:, None] - useB, 0)
            base = nextA * (levelA * levelB * levelB)
            base += nextB * levelB
            nxt = base[:, :, None] + actOff[None, None, :]
            fut = xp.sum(prob[:, :, None] * old[nxt], axis=1)
            reward = prob @ (priceA * soldA + priceB * soldB)
            score = reward[:, None] + fut - actCost[None, :]
            policy[begin:end] = xp.argmax(score, axis=1)
            vals[begin:end] = xp.max(score, axis=1)

        diff = vals - old
        low = float(diff.min().item())
        high = float(diff.max().item())
        vals -= vals[0]
        span = high - low
        if verbose:
            print(f"iteration {it:3d}: span={span:.6g}, reward=[{low:.6f}, {high:.6f}]")
        if not fixed and span < tol:
            break

    if backend == "cuda":
        xp.cuda.Stream.null.synchronize()
        policy = xp.asnumpy(policy)
        vals = xp.asnumpy(vals)

    return {
        "iters": it,
        "span": high - low,
        "profit": (low + high) / 2.0,
        "low": low,
        "high": high,
        "seconds": time.perf_counter() - start,
        "states": count,
        "policy": policy,
        "value": vals,
    }


def simTwo(policy, levelA, levelB, meanA, meanB, gamma=0.5,
           priceA=1.0, priceB=1.0, costA=0.5, costB=0.5,
           days=400000, seed=7643, warm=1000):
    rng = np.random.default_rng(seed)
    state = (0, 0, 0, 0)
    gain = wasteA = wasteB = orderA = orderB = 0.0

    for day in range(days + warm):
        idx = np.ravel_multi_index(state, (levelA, levelA, levelB, levelB))
        act = int(policy[idx])
        qa, qb = divmod(act, levelB)
        demA = int(rng.poisson(meanA))
        demB = int(rng.poisson(meanB))
        stockA = state[0] + state[1]
        stockB = state[2] + state[3]
        soldB = min(demB, stockB)
        sub = int(rng.binomial(max(demB - stockB, 0), gamma))
        soldA = min(demA + sub, stockA)

        if day >= warm:
            gain += priceA * soldA + priceB * soldB - costA * qa - costB * qb
            wasteA += max(state[0] - soldA, 0)
            wasteB += max(state[2] - soldB, 0)
            orderA += qa
            orderB += qb

        nextA = fifoNext(state[:2], qa, soldA)
        nextB = fifoNext(state[2:], qb, soldB)
        state = nextA + nextB

    return {
        "profit": gain / days,
        "waste_a": 100.0 * wasteA / orderA if orderA else 0.0,
        "waste_b": 100.0 * wasteB / orderB if orderB else 0.0,
    }


def saveJson(path, rows):
    with open(path, "w", encoding="utf-8") as stream:
        json.dump(rows, stream, indent=2)

