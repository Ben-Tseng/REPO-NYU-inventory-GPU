import argparse
import json

import numpy as np

from model import CASES, stateNum
from solve import oneVI, saveJson, simTwo, twoVI


def addTwo(args):
    args.add_argument("--case", choices=CASES, default="P1")
    args.add_argument("--backend", choices=("cpu", "cuda"), default="cuda")
    args.add_argument("--tol", type=float, default=1e-4)
    args.add_argument("--iters", type=int, default=1000)
    args.add_argument("--fixed", type=int, default=0)
    args.add_argument("--batch", type=int, default=64)
    args.add_argument("--policy")
    args.add_argument("--sim-days", type=int, default=0)


def show(row):
    keep = {key: val for key, val in row.items() if key not in ("policy", "value")}
    print(json.dumps(keep, indent=2))


def main():
    parser = argparse.ArgumentParser(description="Reproduce perishable inventory VI")
    cmd = parser.add_subparsers(dest="cmd", required=True)

    one = cmd.add_parser("one", help="run the Section 2.3 one-product case")
    one.add_argument("--life", type=int, default=2)
    one.add_argument("--max-order", type=int, default=9)
    one.add_argument("--mean", type=float, default=5.0)
    one.add_argument("--tol", type=float, default=1e-4)
    one.add_argument("--backend", choices=("cpu",), default="cpu")

    two = cmd.add_parser("two", help="run a two-product Table 3 case")
    addTwo(two)

    cmd.add_parser("counts", help="print corrected Table 3 state counts")

    bench = cmd.add_parser("bench", help="time all Table 3 cases")
    bench.add_argument("--backend", choices=("cpu", "cuda"), default="cuda")
    bench.add_argument("--iters", type=int, default=100)
    bench.add_argument("--batch", type=int, default=64)
    bench.add_argument("--out", default="results.json")

    sim = cmd.add_parser("sim", help="simulate a saved two-product policy")
    sim.add_argument("--case", choices=CASES, default="P1")
    sim.add_argument("--policy", required=True)
    sim.add_argument("--days", type=int, default=400000)
    sim.add_argument("--seed", type=int, default=7643)

    args = parser.parse_args()
    if args.cmd == "one":
        show(oneVI(args.life, args.max_order, args.mean, tol=args.tol))
        return

    if args.cmd == "counts":
        for name, (meanA, meanB, levelA, levelB) in CASES.items():
            print(f"{name}: {levelA}^{2} x {levelB}^{2} = {stateNum(levelA, levelB):,}")
        return

    if args.cmd == "bench":
        rows = []
        for name, (meanA, meanB, levelA, levelB) in CASES.items():
            print(f"Running {name} ...", flush=True)
            row = twoVI(levelA, levelB, meanA, meanB, fixed=args.iters,
                        batch=args.batch, backend=args.backend)
            row = {key: val for key, val in row.items() if key not in ("policy", "value")}
            row["case"] = name
            rows.append(row)
            show(row)
        saveJson(args.out, rows)
        return

    if args.cmd == "sim":
        meanA, meanB, levelA, levelB = CASES[args.case]
        data = np.load(args.policy)
        show(simTwo(data["policy"], levelA, levelB, meanA, meanB,
                    days=args.days, seed=args.seed))
        return

    meanA, meanB, levelA, levelB = CASES[args.case]
    row = twoVI(levelA, levelB, meanA, meanB, tol=args.tol,
                maxIt=args.iters, fixed=args.fixed, batch=args.batch,
                backend=args.backend, verbose=True)
    show(row)
    print(f"zero-waste profit upper bound: {(meanA + meanB) * 0.5:.6f}")
    if args.policy:
        np.savez_compressed(args.policy, policy=row["policy"], value=row["value"])
    if args.sim_days:
        show(simTwo(row["policy"], levelA, levelB, meanA, meanB,
                    days=args.sim_days))


if __name__ == "__main__":
    main()
