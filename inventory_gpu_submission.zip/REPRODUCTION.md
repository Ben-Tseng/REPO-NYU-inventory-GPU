# Reproduction record

## Environment

- Date: 2026-10-07 to 2026-10-08
- Local validation host: Apple ARM64, CPU backend, NumPy 2.0.2
- GPU benchmark host: Kaggle, GPU T4 x2 session (the implementation used device 0,
  one Tesla T4), Python 3.13.15, CuPy 14.0.1
- Source paper: Ortega, Hendrix, and Garcia (2019), DOI 10.1007/s11227-018-2692-z

The original paper used two Intel Xeon E5-2620v2 processors and two NVIDIA K80
cards under Ubuntu 16.04 and CUDA 8. The reproduction uses current CuPy-generated
CUDA kernels, so absolute runtimes are not expected to match the old implementation.
CPU and GPU timings below were collected in the same Kaggle session with the same
batch size and 100 Bellman sweeps.

## Verified results

### Single product, Section 2.3

Parameters: shelf life 2, Poisson mean 5, price 1, cost 0.5, maximum order 9,
and convergence tolerance `1e-4`.

| Measure | Paper | This implementation |
|---|---:|---:|
| Average daily profit | 2.215 | 2.21516 |
| Largest order used by policy | 7 | 7 |
| Converged iterations | 12 | 14 |

The small iteration-count difference is sensitive to initialization and relative-value
normalization. The policy value and maximum selected order agree.

### Table 3 state counts

| Case | Printed | Recomputed |
|---|---:|---:|
| P1 | 14,461 | 14,641 |
| P2 | 20,449 | 20,449 |
| P3 | 28,561 | 28,561 |
| P4 | 38,416 | 38,416 |

The last three rows establish that Table 3 uses counts of admissible quantities, not
inclusive maxima. P1 is the transposition `14,461` instead of `14,641`.

### Two products, P1

Parameters: shelf life 2, both Poisson means 5, both prices 1, both costs 0.5,
substitution probability 0.5, 11 quantity levels per product, and tolerance `1e-4`.

- Value iteration converged in 13 iterations.
- Final average-reward interval: `[4.5031745, 4.5032455]`.
- Midpoint estimate: `4.5032100`.
- A 400,000-day simulation with seed 7643 produced daily profit `4.5041738`.
- Simulated waste was `6.0019%` for A and `4.1794%` for B.

The paper reports waste of 5.97% and 4.14%, which is close to the reproduced policy.
Its reported profit of 5.509 cannot follow from the stated model: even zero waste and
complete fulfillment give an upper bound of `(5 + 5) * (1 - 0.5) = 5`. The matching
waste behavior and reproduced value suggest that 5.509 is a typo, plausibly for a
value near 4.509.

The same converged policy was rerun on a Kaggle Tesla T4. It converged in 13
iterations and 2.8061 seconds, with midpoint profit `4.5032100`. The 400,000-day
simulation again produced profit `4.50417375`, waste A `6.00187%`, and waste B
`4.17943%`.

### Kaggle CPU/GPU benchmark, 100 sweeps

| Case | States | Paper CPU (s) | Paper GPU (s) | Kaggle CPU (s) | Kaggle T4 (s) | Kaggle speedup |
|---|---:|---:|---:|---:|---:|---:|
| P1 | 14,641 | 357.89 | 91.29 | 710.09 | 20.16 | 35.22x |
| P2 | 20,449 | 698.20 | 136.84 | 1,284.57 | 30.30 | 42.39x |
| P3 | 28,561 | 1,358.04 | 214.71 | 2,602.89 | 59.24 | 43.94x |
| P4 | 38,416 | 4,241.66 | 361.49 | 5,135.97 | 103.84 | 49.46x |

CPU and GPU profits agreed to within `7.11e-15` in every case. The corresponding
100-sweep profit estimates were `4.5032031`, `5.0036025`, `5.5087173`, and
`6.5183400` for P1 through P4. This demonstrates a real CUDA execution and the
expected increase in GPU benefit as the state/action space grows. It does not claim
cycle-for-cycle equivalence with the paper's hand-written CUDA 8 kernel.

The complete Kaggle cell took 9,958.844 seconds because the four CPU baselines
dominated runtime. The saved private Kaggle version is available at:

<https://www.kaggle.com/code/bentseng82/perishable-inventory-gpu-reproduction?scriptVersionId=356144063>

Downloaded artifacts are stored in `kaggle_results/`, including the notebook,
raw CPU/GPU JSON, benchmark summary, converged P1 policy, validation log, and ZIP.

## Commands used

```bash
python3 -m unittest discover -s tests -v
python3 run.py counts
python3 run.py one --life 2 --max-order 9 --backend cpu
python3 run.py two --case P1 --backend cpu --tol 1e-4 \
  --policy p1_policy.npz --sim-days 100000
python3 run.py sim --case P1 --policy p1_policy.npz --days 400000

# Kaggle-style fixed benchmark (run separately for each backend)
python3 run.py bench --backend cuda --iters 100 --batch 64 --out gpu_results.json
python3 run.py bench --backend cpu --iters 100 --batch 64 --out cpu_results.json
```
