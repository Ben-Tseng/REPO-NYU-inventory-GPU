import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from model import CASES, evtPmf, fifoNext, stateNum
from solve import oneVI, twoVI


class ModelTest(unittest.TestCase):
    def test_fifo(self):
        self.assertEqual(fifoNext((3, 2, 1), 5, 2), (2, 1, 5))
        self.assertEqual(fifoNext((3, 2, 1), 5, 4), (1, 1, 5))

    def test_counts(self):
        vals = [stateNum(a, b) for _, _, a, b in CASES.values()]
        self.assertEqual(vals, [14641, 20449, 28561, 38416])

    def test_events_sum_to_one(self):
        probs = evtPmf(2.0, 3.0, 4, 4, 0.5)
        sums = probs.sum(axis=(2, 3))
        np.testing.assert_allclose(sums, 1.0, atol=1e-12)

    def test_one_product_paper_value(self):
        row = oneVI(life=2, maxOrd=9, tol=1e-4)
        self.assertLess(row["span"], 1e-4)
        self.assertAlmostEqual(row["profit"], 2.215, places=3)
        self.assertEqual(row["max_order"], 7)

    def test_two_product_small(self):
        row = twoVI(3, 3, 1.0, 1.0, tol=1e-5, backend="cpu", batch=16)
        self.assertLess(row["span"], 1e-5)
        self.assertLessEqual(row["profit"], 1.0 + 1e-8)


if __name__ == "__main__":
    unittest.main()

