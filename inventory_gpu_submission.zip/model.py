import math

import numpy as np


CASES = {
    "P1": (5.0, 5.0, 11, 11),
    "P2": (5.0, 6.0, 11, 13),
    "P3": (6.0, 6.0, 13, 13),
    "P4": (7.0, 7.0, 14, 14),
}


def poisPmf(mean, tol=1e-14):
    vals = [math.exp(-mean)]
    total = vals[0]
    k = 0
    while 1.0 - total > tol:
        k += 1
        vals.append(vals[-1] * mean / k)
        total += vals[-1]
        if k > 10000:
            raise RuntimeError("Poisson tail did not converge")
    vals[-1] += 1.0 - total
    return np.asarray(vals, dtype=np.float64)


def capPmf(mean, cap):
    if cap == 0:
        return np.ones(1, dtype=np.float64)
    vals = np.zeros(cap + 1, dtype=np.float64)
    prob = math.exp(-mean)
    total = prob
    vals[0] = prob
    for k in range(1, cap):
        prob *= mean / k
        vals[k] = prob
        total += prob
    vals[cap] = 1.0 - total
    return vals


def subPmf(mean, stock, gamma, cap, tol=1e-14):
    """Joint probability of capped B sales and capped substitution demand."""
    dbPmf = poisPmf(mean, tol)
    joint = np.zeros((stock + 1, cap + 1), dtype=np.float64)

    for db, dbProb in enumerate(dbPmf):
        soldB = min(db, stock)
        short = max(db - stock, 0)
        if short == 0:
            joint[soldB, 0] += dbProb
            continue

        for sub in range(short + 1):
            prob = math.comb(short, sub)
            prob *= gamma**sub * (1.0 - gamma) ** (short - sub)
            joint[soldB, min(sub, cap)] += dbProb * prob

    joint /= joint.sum()
    return joint


def evtPmf(meanA, meanB, maxA, maxB, gamma, tol=1e-14):
    """Build P(capped A sales, capped B sales) for every stock-total pair."""
    sizeA = maxA + 1
    sizeB = maxB + 1
    table = np.zeros((sizeA, sizeB, sizeA, sizeB), dtype=np.float64)

    for stockA in range(sizeA):
        demA = capPmf(meanA, stockA)
        for stockB in range(sizeB):
            sub = subPmf(meanB, stockB, gamma, stockA, tol)
            out = table[stockA, stockB]
            for soldB in range(stockB + 1):
                for add in range(stockA + 1):
                    psub = sub[soldB, add]
                    if not psub:
                        continue
                    for dem, pa in enumerate(demA):
                        out[min(dem + add, stockA), soldB] += pa * psub
            out /= out.sum()

    return table


def fifoNext(state, order, sold):
    left = sold
    stock = []
    for count in state:
        used = min(count, left)
        left -= used
        stock.append(count - used)
    return tuple(stock[1:]) + (order,)


def stateNum(levelA, levelB, life=2):
    return levelA**life * levelB**life
